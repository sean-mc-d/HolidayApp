/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package holidayapp;

/**
 *
 * @author user
 */
public class HolidayApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Resort r1 = new Resort("Dan Smith", 3344, 10 06, 3.5);
        System.out.println(r1.showDetails());
        
        Resort r2 = new Resort("Lisa Mohn", 5386, 04 12, 3.2);
        System.out.println(r2.showDetails());
        
        Hotel h1 = new Hotel();
        System.out.println(h1.hotelDetails());
        
        Cottages c1 = new Cottages();
        System.out.println();
    }
    
}
